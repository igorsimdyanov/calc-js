// Помощники для тестов: нажимаем кнопки калькулятора без браузера.
// Каждое действие — тот же объект, что отправляет кнопка (src/components/keys.js).
import { calculatorReducer, initialState, displayValue } from '../src/logic/reducer.js';

export const digit = (d) => ({ type: 'digit', digit: d });  // кнопки 0–9
export const decimal = { type: 'decimal' };                  // кнопка «,»
export const negate = { type: 'negate' };                    // кнопка «+/−»
export const plus = { type: 'operator', operator: '+' };     // кнопка «+»
export const minus = { type: 'operator', operator: '-' };    // кнопка «−»
export const times = { type: 'operator', operator: '*' };    // кнопка «×»
export const divide = { type: 'operator', operator: '/' };   // кнопка «÷»
export const equals = { type: 'equals' };                    // кнопка «=»
export const clear = { type: 'clear' };                      // кнопка «C»

// Набрать число, как это делает пользователь: number('12,5') — это 1, 2, «,», 5
export const number = (text) => [...text].map((ch) => (ch === ',' ? decimal : digit(ch)));

// Нажать кнопки по очереди, начиная с только что открытого калькулятора (ОП-1)
export const press = (...actions) => actions.flat().reduce(calculatorReducer, initialState);

// Продолжить нажатия с уже полученного состояния — для проверки промежуточных шагов
export const pressFrom = (state, ...actions) => actions.flat().reduce(calculatorReducer, state);

// Текст основного экрана — так, как его видит пользователь: '1 234,5'
export const display = (state) => displayValue(state);

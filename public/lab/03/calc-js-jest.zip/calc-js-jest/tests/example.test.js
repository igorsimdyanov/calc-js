import { press, number, display } from './helpers.js';

// Примеры: тест-кейсы раздела «Ввод чисел» из docs/test-cases-short.md

test('TC-INP-01: ввод целого числа', () => {
  const state = press(number('123')); // шаги: нажать 1, 2, 3
  expect(display(state)).toBe('123'); // экран: 123
  expect(state.expression).toBe(''); //  выражение пустое
});

test('TC-INP-03: ввод дробного числа', () => {
  const state = press(number('3,14')); // шаги: нажать 3, «,», 1, 4
  expect(display(state)).toBe('3,14'); // экран: 3,14
});
